
<main class="main">
<section id="hero" class="hero section dark-background">
    <div class="info d-flex">
        <div class="container">
        <div class="row" data-aos="fade-up" data-aos-delay="100">
            <div class="col text-center">
                <p class="mt-2">Pengasuh</p>
            </div>
        </div>
        </div>
    </div>

    <div class="carousel slide">
        <div class="carousel-item active">
        <img src="<?= base_url();?>/aset_dashboard/img/img_dashboard/c4.png" alt="">
        </div>

    </div>

    </section>
        

</main>

