<?php
echo view('dashboard/layout/header');
echo view('dashboard/layout/isi');
echo view('dashboard/layout/footer');
?>