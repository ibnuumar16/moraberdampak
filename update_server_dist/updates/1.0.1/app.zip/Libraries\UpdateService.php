<?php

namespace App\Libraries;

use CodeIgniter\Files\File;

class UpdateService
{
    protected $updateUrl = 'https://update.undanganaesthetic.my.id';
    protected $tempPath;
    protected $backupPath;

    public function __construct()
    {
        $this->tempPath = WRITEPATH . 'uploads/temp_update/';
        $this->backupPath = WRITEPATH . 'uploads/backups/';
        
        if (!is_dir($this->tempPath)) mkdir($this->tempPath, 0755, true);
        if (!is_dir($this->backupPath)) mkdir($this->backupPath, 0755, true);
    }

    public function checkVersion()
    {
        $client = \Config\Services::curlrequest();
        
        try {
            $response = $client->request('GET', $this->updateUrl . '/latest.json', [
                'verify' => false,
                'timeout' => 5
            ]);
            
            $data = json_decode($response->getBody(), true);
            
            if (!$data) return ['status' => false, 'message' => 'Invalid server response'];

            // Get current version from DB
            $db = \Config\Database::connect();
            $current = $db->table('system_versions')
                          ->orderBy('id', 'DESC')
                          ->limit(1)
                          ->get()
                          ->getRow();
            
            $currentVersion = $current ? $current->version : '1.0.0';
            
            return [
                'status' => true,
                'current_version' => $currentVersion,
                'remote_version' => $data['version'],
                'has_update' => version_compare($data['version'], $currentVersion, '>'),
                'details' => $data
            ];
            
        } catch (\Exception $e) {
            return ['status' => false, 'message' => $e->getMessage()];
        }
    }

    public function downloadUpdate($version)
    {
        $files = ['app.zip', 'public.zip', 'migrations.zip'];
        $downloaded = [];
        
        $client = \Config\Services::curlrequest();
        
        foreach ($files as $file) {
            try {
                $url = $this->updateUrl . "/updates/{$version}/{$file}";
                $savePath = $this->tempPath . $file;
                
                $response = $client->request('GET', $url, [
                    'verify' => false,
                    'sink' => $savePath
                ]);
                
                if ($response->getStatusCode() === 200) {
                    $downloaded[] = $savePath;
                } else {
                    return false;
                }
            } catch (\Exception $e) {
                return false;
            }
        }
        
        return true;
    }

    public function extractFiles()
    {
        $zip = new \ZipArchive();
        $rootParams = FCPATH . '../'; // Root project from public/index.php
        
        // Extract App
        if ($zip->open($this->tempPath . 'app.zip') === TRUE) {
            $zip->extractTo(APPPATH . '../'); // Extract to app folder parent
            $zip->close();
        }
        
        // Extract Public
        if ($zip->open($this->tempPath . 'public.zip') === TRUE) {
            $zip->extractTo(FCPATH);
            $zip->close();
        }
        
        // Extract Migrations
        if ($zip->open($this->tempPath . 'migrations.zip') === TRUE) {
            $zip->extractTo(APPPATH . 'Database/Migrations/');
            $zip->close();
        }
        
        return true;
    }

    public function runMigration()
    {
        $migrate = \Config\Services::migrations();
        
        try {
            $migrate->latest();
            return true;
        } catch (\Throwable $e) {
            return false;
        }
    }
    
    public function backup()
    {
        helper('backup');
        return create_system_backup($this->backupPath);
    }
}
