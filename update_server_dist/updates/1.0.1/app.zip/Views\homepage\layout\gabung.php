<?php
echo view('homepage/layout/header');
echo view('homepage/layout/isi');
echo view('homepage/layout/footer');
?>